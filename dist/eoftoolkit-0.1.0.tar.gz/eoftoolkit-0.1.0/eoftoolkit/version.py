"""Version information for EOFtoolkit."""

__version__ = '0.1.0'